export interface Genero {
    id?: number;
    descricao: string;
}